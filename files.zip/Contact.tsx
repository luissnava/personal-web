export default function Contact() {
  const contactLinks = [
    {
      label: "Email",
      value: "pedro@example.com",
      href: "mailto:pedro@example.com",
      description: "Escríbeme directamente",
    },
    {
      label: "LinkedIn",
      value: "linkedin.com/in/pedro-hernandez",
      href: "https://www.linkedin.com/in/pedro-hernandez",
      description: "Conectemos profesionalmente",
      external: true,
    },
    {
      label: "GitHub",
      value: "github.com/pedro-hernandez",
      href: "https://github.com/pedro-hernandez",
      description: "Revisa mi código",
      external: true,
    },
  ];

  return (
    <section
      id="contacto"
      className="py-24 px-6 max-w-6xl mx-auto"
      aria-labelledby="contacto-heading"
    >
      {/* Divider */}
      <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent mb-24" />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
        {/* Texto */}
        <div>
          <span className="text-xs tracking-[0.3em] text-amber-400/70 uppercase font-mono mb-4 block">
            Contacto
          </span>
          <h2
            id="contacto-heading"
            className="font-serif text-3xl sm:text-4xl text-white/90 mb-6 leading-tight"
          >
            ¿Tienes un proyecto
            <br />
            <span className="text-white/40">en mente?</span>
          </h2>
          <p className="text-white/40 text-sm sm:text-base leading-relaxed max-w-sm">
            Estoy disponible para proyectos freelance, colaboraciones y
            oportunidades de trabajo. No dudes en escribirme.
          </p>

          <div className="mt-10">
            <a
              href="mailto:pedro@example.com"
              className="inline-flex items-center gap-3 bg-amber-400 text-[#0a0a0a] text-sm font-medium px-6 py-3 hover:bg-amber-300 transition-colors duration-300 rounded-sm tracking-wide"
            >
              <MailIcon />
              Enviarme un mensaje
            </a>
          </div>
        </div>

        {/* Links de contacto */}
        <div className="space-y-px bg-white/5">
          {contactLinks.map((item) => (
            <a
              key={item.label}
              href={item.href}
              target={item.external ? "_blank" : undefined}
              rel={item.external ? "noopener noreferrer" : undefined}
              className="flex items-center justify-between bg-[#0a0a0a] px-7 py-5 hover:bg-white/[0.03] transition-colors duration-300 group"
              aria-label={`${item.label}: ${item.description}`}
            >
              <div>
                <p className="text-[11px] font-mono text-white/25 uppercase tracking-widest mb-1">
                  {item.label}
                </p>
                <p className="text-sm text-white/60 group-hover:text-white/90 transition-colors duration-300">
                  {item.value}
                </p>
              </div>
              <span className="text-white/20 group-hover:text-amber-400 transition-colors duration-300">
                <ArrowUpRightIcon />
              </span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

function MailIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
      <polyline points="22,6 12,13 2,6" />
    </svg>
  );
}

function ArrowUpRightIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <line x1="7" y1="17" x2="17" y2="7" />
      <polyline points="7 7 17 7 17 17" />
    </svg>
  );
}

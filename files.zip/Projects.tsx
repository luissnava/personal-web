export default function Projects() {
  const projects = [
    {
      number: "01",
      title: "Nombre del proyecto",
      description:
        "Descripción breve del proyecto, qué problema resuelve y cuál fue tu rol. Menciona tecnologías clave y el impacto logrado.",
      tags: ["React", "Next.js", "Tailwind"],
      link: "#",
      repo: "#",
      featured: true,
    },
    {
      number: "02",
      title: "Nombre del proyecto",
      description:
        "Descripción breve del proyecto, qué problema resuelve y cuál fue tu rol. Menciona tecnologías clave y el impacto logrado.",
      tags: ["TypeScript", "Zustand", "Vite"],
      link: "#",
      repo: "#",
      featured: false,
    },
    {
      number: "03",
      title: "Nombre del proyecto",
      description:
        "Descripción breve del proyecto, qué problema resuelve y cuál fue tu rol. Menciona tecnologías clave y el impacto logrado.",
      tags: ["Astro", "CSS Modules", "API REST"],
      link: "#",
      repo: "#",
      featured: false,
    },
  ];

  return (
    <section
      id="proyectos"
      className="py-24 px-6 max-w-6xl mx-auto"
      aria-labelledby="proyectos-heading"
    >
      <div className="mb-14">
        <span className="text-xs tracking-[0.3em] text-amber-400/70 uppercase font-mono mb-4 block">
          Portafolio
        </span>
        <h2
          id="proyectos-heading"
          className="font-serif text-3xl sm:text-4xl text-white/90 leading-tight"
        >
          Proyectos seleccionados<span className="text-amber-400">.</span>
        </h2>
      </div>

      <div className="space-y-px bg-white/5 border border-white/5">
        {projects.map((project) => (
          <article
            key={project.number}
            className="bg-[#0a0a0a] p-7 sm:p-9 grid grid-cols-1 lg:grid-cols-[80px_1fr_auto] gap-6 items-start hover:bg-white/[0.02] transition-colors duration-300 group"
          >
            {/* Número */}
            <span className="font-mono text-xs text-white/15 pt-1">
              {project.number}
            </span>

            {/* Contenido */}
            <div>
              <div className="flex flex-wrap items-center gap-3 mb-3">
                <h3 className="font-serif text-xl text-white/90 group-hover:text-white transition-colors duration-300">
                  {project.title}
                </h3>
                {project.featured && (
                  <span className="text-[10px] tracking-widest uppercase font-mono text-amber-400/70 border border-amber-400/20 px-2 py-0.5">
                    Destacado
                  </span>
                )}
              </div>
              <p className="text-sm text-white/40 leading-relaxed max-w-xl mb-5">
                {project.description}
              </p>
              <ul className="flex flex-wrap gap-2" aria-label="Tecnologías utilizadas">
                {project.tags.map((tag) => (
                  <li
                    key={tag}
                    className="text-[11px] font-mono text-white/30 border border-white/10 px-2 py-0.5 rounded-sm"
                  >
                    {tag}
                  </li>
                ))}
              </ul>
            </div>

            {/* Links */}
            <div className="flex gap-4 items-center lg:pt-1">
              <a
                href={project.repo}
                target="_blank"
                rel="noopener noreferrer"
                className="text-white/25 hover:text-white/70 transition-colors"
                aria-label={`Ver repositorio de ${project.title}`}
              >
                <GitHubIcon />
              </a>
              <a
                href={project.link}
                target="_blank"
                rel="noopener noreferrer"
                className="text-white/25 hover:text-amber-400 transition-colors"
                aria-label={`Ver demo de ${project.title}`}
              >
                <ExternalLinkIcon />
              </a>
            </div>
          </article>
        ))}
      </div>

      <div className="mt-8 text-center">
        <a
          href="https://github.com/pedro-hernandez"
          target="_blank"
          rel="noopener noreferrer"
          className="text-sm text-white/30 hover:text-white/60 transition-colors tracking-wide inline-flex items-center gap-2"
          aria-label="Ver todos los proyectos en GitHub (abre en nueva pestaña)"
        >
          Ver todos en GitHub
          <span className="w-4 h-px bg-white/20" />
        </a>
      </div>
    </section>
  );
}

function GitHubIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" />
    </svg>
  );
}

function ExternalLinkIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6M15 3h6v6M10 14L21 3" />
    </svg>
  );
}

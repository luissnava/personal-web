export default function About() {
  const stats = [
    { value: "3+", label: "Años de experiencia" },
    { value: "20+", label: "Proyectos entregados" },
    { value: "100%", label: "Compromiso con calidad" },
  ];

  return (
    <section
      id="sobre-mi"
      className="py-24 px-6 max-w-6xl mx-auto"
      aria-labelledby="sobre-mi-heading"
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        {/* Texto */}
        <div>
          <span className="text-xs tracking-[0.3em] text-amber-400/70 uppercase font-mono mb-4 block">
            Sobre mí
          </span>
          <h2
            id="sobre-mi-heading"
            className="font-serif text-3xl sm:text-4xl text-white/90 mb-6 leading-tight"
          >
            Código limpio,
            <br />
            <span className="text-white/40">experiencias memorables</span>
          </h2>
          <div className="space-y-4 text-white/50 leading-relaxed text-sm sm:text-base">
            <p>
              Soy un desarrollador Frontend apasionado por construir productos
              web que combinan rendimiento técnico con diseño cuidadoso. Mi
              enfoque está en React, Next.js y la web moderna.
            </p>
            <p>
              Disfruto cada etapa del proceso: desde arquitectar componentes
              reutilizables hasta afinar la microinteracción que hace que una
              interfaz se sienta viva. Para mí, el detalle importa.
            </p>
            <p>
              Cuando no estoy codificando, estoy aprendiendo sobre diseño de
              sistemas, rendimiento del navegador o contribuyendo a proyectos
              open source.
            </p>
          </div>

          <div className="mt-8">
            <a
              href="https://www.linkedin.com/in/pedro-hernandez"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-sm text-amber-400/80 hover:text-amber-400 transition-colors group"
              aria-label="Ver perfil de LinkedIn de Pedro Hernandez (abre en nueva pestaña)"
            >
              <LinkedInIcon />
              Ver perfil en LinkedIn
              <span className="w-4 h-px bg-amber-400/40 group-hover:w-8 group-hover:bg-amber-400 transition-all duration-300" />
            </a>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 gap-px bg-white/5 border border-white/5 rounded-sm overflow-hidden">
          {stats.map((stat, i) => (
            <div
              key={i}
              className="bg-[#0a0a0a] px-8 py-7 flex items-center justify-between group hover:bg-white/[0.02] transition-colors duration-300"
            >
              <span className="text-white/40 text-sm">{stat.label}</span>
              <span className="font-serif text-3xl text-white/90 group-hover:text-amber-400 transition-colors duration-300">
                {stat.value}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function LinkedInIcon() {
  return (
    <svg
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="currentColor"
      aria-hidden="true"
    >
      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
    </svg>
  );
}

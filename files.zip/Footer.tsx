export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-white/5 px-6 py-10 max-w-6xl mx-auto" role="contentinfo">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <p className="font-serif text-white/30 text-sm">
            Pedro Luis Hernandez Nava<span className="text-amber-400/60">.</span>
          </p>
          <p className="text-xs text-white/15 mt-1 font-mono">
            Desarrollador Frontend · México
          </p>
        </div>

        <div className="flex items-center gap-6">
          <a
            href="https://www.linkedin.com/in/pedro-hernandez"
            target="_blank"
            rel="noopener noreferrer"
            className="text-white/20 hover:text-white/50 transition-colors text-xs font-mono tracking-wide"
            aria-label="LinkedIn (abre en nueva pestaña)"
          >
            LinkedIn
          </a>
          <a
            href="https://github.com/pedro-hernandez"
            target="_blank"
            rel="noopener noreferrer"
            className="text-white/20 hover:text-white/50 transition-colors text-xs font-mono tracking-wide"
            aria-label="GitHub (abre en nueva pestaña)"
          >
            GitHub
          </a>
          <a
            href="mailto:pedro@example.com"
            className="text-white/20 hover:text-white/50 transition-colors text-xs font-mono tracking-wide"
          >
            Email
          </a>
        </div>
      </div>

      <div className="mt-8 pt-6 border-t border-white/[0.04] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
        <p className="text-[11px] text-white/15 font-mono">
          © {year} Pedro Luis Hernandez Nava. Todos los derechos reservados.
        </p>
        <p className="text-[11px] text-white/10 font-mono">
          Hecho con Next.js · Tailwind CSS
        </p>
      </div>
    </footer>
  );
}

import type { Metadata } from "next";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import About from "@/components/About";
import Skills from "@/components/Skills";
import Projects from "@/components/Projects";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "Pedro Luis Hernandez Nava · Desarrollador Frontend",
  description:
    "Desarrollador Frontend especializado en React y Next.js. Construyo interfaces web rápidas, accesibles y con atención al detalle. Disponible para proyectos freelance.",
  keywords: [
    "desarrollador frontend",
    "React",
    "Next.js",
    "TypeScript",
    "Tailwind CSS",
    "Pedro Hernandez",
    "portafolio web",
    "México",
  ],
  authors: [{ name: "Pedro Luis Hernandez Nava" }],
  creator: "Pedro Luis Hernandez Nava",
  openGraph: {
    title: "Pedro Luis Hernandez Nava · Desarrollador Frontend",
    description:
      "Desarrollador Frontend especializado en React y Next.js. Interfaces web rápidas, accesibles y con atención al detalle.",
    url: "https://pedrolhernandez.dev",
    siteName: "Pedro Luis Hernandez Nava",
    locale: "es_MX",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Pedro Luis Hernandez Nava · Desarrollador Frontend",
    description:
      "Desarrollador Frontend especializado en React y Next.js. Disponible para proyectos.",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  alternates: {
    canonical: "https://pedrolhernandez.dev",
  },
};

export default function Home() {
  return (
    <>
      <Header />
      <main id="main-content">
        <Hero />
        <About />
        <Skills />
        <Projects />
        <Contact />
      </main>
      <Footer />
    </>
  );
}

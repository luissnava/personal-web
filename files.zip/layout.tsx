import type { Metadata } from "next";
import { Playfair_Display, Space_Mono } from "next/font/google";
import "./globals.css";

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-serif",
  display: "swap",
});

const spaceMono = Space_Mono({
  subsets: ["latin"],
  weight: ["400", "700"],
  variable: "--font-mono",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://pedrolhernandez.dev"),
};

// JSON-LD para SEO estructurado
const jsonLd = {
  "@context": "https://schema.org",
  "@type": "Person",
  name: "Pedro Luis Hernandez Nava",
  jobTitle: "Desarrollador Frontend",
  url: "https://pedrolhernandez.dev",
  sameAs: [
    "https://www.linkedin.com/in/pedro-hernandez",
    "https://github.com/pedro-hernandez",
  ],
  knowsAbout: ["React", "Next.js", "TypeScript", "Tailwind CSS", "JavaScript"],
  address: {
    "@type": "PostalAddress",
    addressCountry: "MX",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es" className={`${playfair.variable} ${spaceMono.variable}`}>
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
      </head>
      <body className="bg-[#0a0a0a] text-white antialiased selection:bg-amber-400/20 selection:text-amber-200">
        {/* Skip to main content para accesibilidad */}
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-[100] focus:px-4 focus:py-2 focus:bg-amber-400 focus:text-[#0a0a0a] focus:text-sm focus:rounded-sm"
        >
          Saltar al contenido principal
        </a>
        {children}
      </body>
    </html>
  );
}
